using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelProgress : MonoBehaviour
{
    // Update is called once per frame
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("WallClimb"))
        {
            Manager.Instance.WallUp++;
            Destroy(collision.gameObject);
        }
        if (collision.gameObject.CompareTag("Dash"))
        {
            Manager.Instance.DashUp++;
            Destroy(collision.gameObject);
        }
        if (collision.gameObject.CompareTag("DoubleJump"))
        {
            Manager.Instance.DoubleJumpUp++;
            Destroy(collision.gameObject);
        }
       
        if (collision.gameObject.CompareTag("GateOneEnter"))
        {
           Manager.Instance.OneEnter = true;
        }
         if (collision.gameObject.CompareTag("GateOneFinish"))
        {
            Manager.Instance.FinishOne++;
            Manager.Instance.OneEnter = false;
            Manager.Instance.OneExit = true;
        }
        if (collision.gameObject.CompareTag("GateTwoEnter"))
        {
            Manager.Instance.OneExit = false;
            Manager.Instance.TwoEnter = true;
        }
         if (collision.gameObject.CompareTag("GateTwoFinish"))
        {
            Manager.Instance.FinishTwo++;
            Manager.Instance.TwoEnter = false;
            Manager.Instance.TwoExit = true;
        }
        if (collision.gameObject.CompareTag("GateThreeEnter"))
        {
            Manager.Instance.TwoExit = false;
            Manager.Instance.ThreeEnter = true;
        }
        if (collision.gameObject.CompareTag("GateThreeFinish"))
        {
            Manager.Instance.ThreeEnter = false;
            Manager.Instance.FinishThree++;
        }
    }
}
