using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PrizeCounter : MonoBehaviour
{
    public int sceneID;
    public GameObject player;
    public Text LivesText;
    public bool TimeUp = true;
    public Canvas DeadCanvas;
   // public Text PrizesText;
    // Start is called before the first frame update
    void Start()
    {
        LivesText.text = ("Lives: ") + Manager.Instance.livesHad.ToString();
        DeadCanvas.enabled = false;
    }

    void Update()
    {
        if (Manager.Instance.livesHad == 0){
            Manager.Instance.livesHad = 3;
            Manager.Instance.MovementEnabled = false;
            DeadCanvas.enabled = true;

        }
    }
    private void OnCollisionEnter2D(Collision2D other)
    {
        
        if (other.gameObject.tag == "Enemy" && TimeUp == true)
        {
            //Player loses a life
            TimeUp = false;
            Manager.Instance.livesHad--;
            LivesText.text = ("Lives: ") + Manager.Instance.livesHad.ToString();
            SecondsWaiting();

        }
    }
    public void SecondsWaiting()
    {
        StartCoroutine(WaitCouple());
    }
    
    IEnumerator WaitCouple()
    {
        yield return new WaitForSeconds(1);
       TimeUp = true;
    
    }


}
 