using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSpawner : MonoBehaviour
{
    public GameObject Player;
    public GameObject SpawnEnter1;
    public GameObject SpawnExit1;
    public GameObject SpawnEnter2;
    public GameObject SpawnExit2;
    public GameObject SpawnEnter3;
    // Start is called before the first frame update
    void Start()
        {
            if (Manager.Instance.OneEnter == true){
            Player.transform.position = SpawnEnter1.transform.position;
            }
            if (Manager.Instance.OneExit == true){
            Player.transform.position = SpawnExit1.transform.position;
            }
            if (Manager.Instance.TwoEnter == true){
            Player.transform.position = SpawnEnter2.transform.position;
            }
            if (Manager.Instance.TwoExit == true){
            Player.transform.position = SpawnExit2.transform.position;
            }
            if (Manager.Instance.ThreeEnter == true){
            Player.transform.position = SpawnEnter3.transform.position;
            }
        }
        
    }


